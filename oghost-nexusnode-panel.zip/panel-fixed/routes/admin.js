/**
 * @fileoverview This module sets up administrative routes for managing and monitoring server nodes
 * within the network. It provides functionality to create, delete, and debug nodes, as well as check
 * their current status. User authentication and admin role verification are enforced for access to
 * these routes.
 */

const express = require("express");
const router = express.Router();
const { v4: uuidv4 } = require("uuid");
const axios = require("axios");
const { db } = require("../handlers/db.js");
const config = require("../config.json");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const multer = require("multer");
const path = require("path");
const fs = require("node:fs");
const { logAudit } = require("../handlers/auditlog.js");
const nodemailer = require("nodemailer");
const { sendTestEmail } = require("../handlers/email.js");

/**
 * Middleware to verify if the user is an administrator.
 * Checks if the user object exists and if the user has admin privileges. If not, redirects to the
 * home page. If the user is an admin, proceeds to the next middleware or route handler.
 *
 * @param {Object} req - The request object, containing user data.
 * @param {Object} res - The response object.
 * @param {Function} next - The next middleware or route handler to be executed.
 * @returns {void} Either redirects or proceeds by calling next().
 */
function isAdmin(req, res, next) {
  if (!req.user || req.user.admin !== true) {
    return res.redirect("../");
  }
  next();
}

async function doesUserExist(username) {
  const users = await db.get("users");
  if (users) {
    return users.some((user) => user.username === username);
  } else {
    return false; // If no users found, return false
  }
}

async function doesEmailExist(email) {
  const users = await db.get("users");
  if (users) {
    return users.some((user) => user.email === email);
  } else {
    return false; // If no users found, return false
  }
}

/**
 * Checks the operational status of a node by making an HTTP request to its API.
 * Updates the node's status based on the response or sets it as 'Offline' if the request fails.
 * This status check and update are persisted in the database.
 *
 * @param {Object} node - The node object containing details such as address, port, and API key.
 * @returns {Promise<Object>} Returns the updated node object after attempting to verify its status.
 */
async function checkNodeStatus(node) {
  try {
    const RequestData = {
      method: "get",
      url: "http://" + node.address + ":" + node.port + "/",
      auth: {
        username: "OGhost × NexusNode",
        password: node.apiKey,
      },
      headers: {
        "Content-Type": "application/json",
      },
    };
    const response = await axios(RequestData);
    const { versionFamily, versionRelease, online, remote, docker } =
      response.data;

    node.status = "Online";
    node.versionFamily = versionFamily;
    node.versionRelease = versionRelease;
    node.remote = remote;

    await db.set(node.id + "_node", node); // Update node info with new details
    return node;
  } catch (error) {
    node.status = "Offline";
    await db.set(node.id + "_node", node); // Update node as offline if there's an error
    return node;
  }
}

router.get("/admin/apikeys", isAdmin, async (req, res) => {
  try {
    res.render("admin/apikeys", {
      req,
      user: req.user,
      apiKeys: (await db.get("apiKeys")) || [],
      name: (await db.get("name")) || "OGhost × NexusNode 2026",
      logo: (await db.get("logo")) || false,
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve API keys" });
  }
});

router.post("/apikeys/create", isAdmin, async (req, res) => {
  try {
    const newApiKey = {
      id: uuidv4(),
      key: "hpk_" + uuidv4(),
      createdAt: new Date().toISOString(),
    };

    let apiKeys = (await db.get("apiKeys")) || [];
    apiKeys.push(newApiKey);
    await db.set("apiKeys", apiKeys);

    res.status(201).json(newApiKey);
  } catch (error) {
    res.status(500).json({ error: "Failed to create API key" });
  }
});

router.delete("/apikeys/delete", isAdmin, async (req, res) => {
  try {
    const { keyId } = req.body;
    let apiKeys = (await db.get("apiKeys")) || [];
    apiKeys = apiKeys.filter((key) => key.id !== keyId);
    await db.set("apiKeys", apiKeys);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: "Failed to delete API key" });
  }
});

/**
 * GET /nodes/debug
 * Asynchronously retrieves and updates the status of all nodes registered in the database.
 * Available only to administrators. The status of each node is checked and updated through a
 * specific function call which queries the node's API.
 *
 * @returns {Response} Returns a JSON array of all nodes with their updated statuses.
 */
router.get("/nodes/debug", isAdmin, async (req, res) => {
  const nodeIds = (await db.get("nodes")) || [];
  const nodes = await Promise.all(
    nodeIds.map((id) => db.get(id + "_node").then(checkNodeStatus)),
  );
  res.json(nodes);
});

/**
 * GET /account/debug
 * Provides debug information about the currently logged-in user. Available only to administrators.
 * Ensures that user data is available in the request object, then returns this data in JSON format.
 *
 * @returns {Response} Returns a JSON object containing user details if available; otherwise, sends a debug error message.
 */
router.get("/account/debug", isAdmin, async (req, res) => {
  if (!req.user) res.send("no req.user present!");
  res.json(req.user);
});

/**
 * GET /admin/node/:id/configure-command
 * Generates a configuration command for a specific node.
 */
router.get("/admin/node/:id/configure-command", isAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    // Fetch the node from the database
    const node = await db.get(id + "_node");

    if (!node) {
      return res.status(404).json({ error: "Node not found" });
    }

    // Generate a new configure key
    const configureKey = uuidv4();

    // Update the node with the new configure key
    node.configureKey = configureKey;
    await db.set(id + "_node", node);

    // Construct the configuration command
    const panelUrl = `${req.protocol}://${req.get("host")}`;
    const configureCommand = `npm run configure -- --panel ${panelUrl} --key ${configureKey}`;

    // Return the configuration command
    res.json({
      nodeId: id,
      configureCommand: configureCommand,
    });
  } catch (error) {
    console.error("Error generating configure command:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /admin/overview
 * Retrieves counts of users, nodes, images, and instances from the database.
 * Available only to administrators and renders an overview page displaying the counts.
 *
 * @returns {Response} Renders the 'overview' view with the total counts.
 */
router.get("/admin/overview", isAdmin, async (req, res) => {
  try {
    const users = (await db.get("users")) || [];
    const nodes = (await db.get("nodes")) || [];
    const images = (await db.get("images")) || [];
    const instances = (await db.get("instances")) || [];

    // Calculate totals
    const usersTotal = users.length;
    const nodesTotal = nodes.length;
    const imagesTotal = images.length;
    const instancesTotal = instances.length;

    // Check first visit
    const firstVisitKey = `firstVisit_${req.user.userId}`;
    const hasVisitedBefore = await db.get(firstVisitKey);
    let showWelcome = false;

    if (!hasVisitedBefore) {
      showWelcome = true;
      await db.set(firstVisitKey, true);
    }

    res.render("admin/overview", {
      req,
      user: req.user,
      name: (await db.get("name")) || "OGhost × NexusNode 2026",
      logo: (await db.get("logo")) || false,
      usersTotal,
      nodesTotal,
      imagesTotal,
      instancesTotal,
      version: config.version,
      showWelcome,
    });
  } catch (error) {
    res
      .status(500)
      .send({ error: "Failed to retrieve data from the database." });
  }
});

router.get("/admin/analytics", isAdmin, async (req, res) => {
  try {
    const analytics = (await db.get("analytics")) || [];

    const pageViews = analytics.reduce((acc, item) => {
      if (item?.path) {
        acc[item.path] = (acc[item.path] || 0) + 1;
      }
      return acc;
    }, {});

    const methodCounts = analytics.reduce((acc, item) => {
      if (item?.method) {
        acc[item.method] = (acc[item.method] || 0) + 1;
      }
      return acc;
    }, {});

    const timeSeriesData = analytics
      .filter((item) => item?.timestamp && item?.path)
      .map((item) => ({
        timestamp: item.timestamp,
        path: item.path,
      }));

    res.render("admin/analytics", {
      req,
      user: req.user,
      pageViews,
      methodCounts,
      timeSeriesData,
      name: "Analytics",
      logo: true,
    });
  } catch (error) {
    console.error("Error in /admin/analytics:", error);
    res.status(500).render("error", { error: "Failed to load analytics data" });
  }
});

router.get("/api/analytics", isAdmin, async (req, res) => {
  try {
    // Check if user is authenticated and has admin rights
    if (!req.user || !req.user.admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const analytics = (await db.get("analytics")) || [];

    // Process analytics data
    const totalRequests = analytics.length;
    const uniqueVisitors = new Set(
      analytics.map((item) => item?.ip).filter(Boolean),
    ).size;
    const avgRequestsPerHour = totalRequests > 0 ? totalRequests / 24 : 0; // Avoid division by zero

    // Get page counts with safety checks
    const pageCounts = analytics.reduce((acc, item) => {
      if (item?.path) {
        acc[item.path] = (acc[item.path] || 0) + 1;
      }
      return acc;
    }, {});

    // Safely get top page
    const sortedPages = Object.entries(pageCounts).sort((a, b) => b[1] - a[1]);
    const topPage =
      sortedPages.length > 0 ? sortedPages[0][0] : "No pages visited";

    // Traffic over time (hourly)
    const trafficOverTime = Array(24).fill(0);
    analytics.forEach((item) => {
      if (item?.timestamp) {
        try {
          const hour = new Date(item.timestamp).getHours();
          if (!isNaN(hour) && hour >= 0 && hour < 24) {
            trafficOverTime[hour]++;
          }
        } catch (e) {
          console.error("Invalid timestamp:", item.timestamp);
        }
      }
    });

    // Top 5 pages
    const topPages = sortedPages.slice(0, 5);

    res.json({
      totalRequests,
      uniqueVisitors,
      avgRequestsPerHour,
      topPage,
      trafficOverTime: {
        labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
        data: trafficOverTime,
      },
      topPages: {
        labels: topPages.map(([page]) => page),
        data: topPages.map(([, count]) => count),
      },
    });
  } catch (error) {
    console.error("Error in /api/analytics:", error);
    res.status(500).json({ error: "Failed to process analytics data" });
  }
});

/**
 * POST /nodes/create
 * Creates a new node with a unique configureKey for secure configuration.
 */
router.post("/nodes/create", isAdmin, async (req, res) => {
  const configureKey = uuidv4(); // Generate a unique configureKey
  const node = {
    id: uuidv4(),
    name: req.body.name,
    tags: req.body.tags,
    ram: req.body.ram,
    disk: req.body.disk,
    processor: req.body.processor,
    address: req.body.address,
    port: req.body.port,
    apiKey: null, // Set to null initially
    configureKey: configureKey, // Add the configureKey
    status: "Unconfigured", // Status to indicate pending configuration
  };

  if (
    !req.body.name ||
    !req.body.tags ||
    !req.body.ram ||
    !req.body.disk ||
    !req.body.processor ||
    !req.body.address ||
    !req.body.port
  ) {
    return res.status(400).send("Form validation failure.");
  }

  await db.set(node.id + "_node", node);

  const nodes = (await db.get("nodes")) || [];
  nodes.push(node.id);
  await db.set("nodes", nodes);

  // Return the node object including the configureKey
  logAudit(req.user.userId, req.user.username, "node:create", req.ip);
  res.status(201).json({
    ...node,
    configureKey: configureKey, // Include configureKey in the response
  });
});

router.get("/admin/node/:id/stats", isAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    // 1. Get node from database
    const node = await db.get(`${id}_node`);
    if (!node) {
      return res.status(404).render('admin/error', {
        error: "Node not found",
        user: req.user
      });
    }

    // 2. Count instances on this node
    const instances = (await db.get("instances")) || [];
    const instanceCount = instances.filter(i => i.Node?.id === id).length;

    // 3. Default stats (shown when node is offline)
    let stats = {
      memory: { total: 0, used: 0, free: 0, percent: 0 },
      disk: { total: 0, used: 0, free: 0, percent: 0 },
      cpu: { usage: 0, cores: 0 },
      uptime: "0d 0h 0m",
      status: "Offline"
    };

    // 4. Try to fetch live stats
    try {
      const response = await axios.get(`http://${node.address}:${node.port}/stats`, {
        headers: {
          Authorization: `Basic ${Buffer.from(`OGhost × NexusNode:${node.apiKey}`).toString('base64')}`
        },
        timeout: 5000 // 5 second timeout
      });

      if (response.data) {
        stats = {
          memory: response.data.memory,
          disk: response.data.disk,
          cpu: response.data.cpu,
          uptime: response.data.uptime,
          status: response.data.status || "Online"
        };
      }
    } catch (error) {
      console.error(`Failed to fetch stats for node ${id}:`, error.message);
      stats.error = error.message;
    }

    // 5. Render the page with all data
    res.render("admin/nodestats", {
      req,
      user: req.user,
      stats,
      node,
      instanceCount,
      status: stats.status,
      name: "Node Statistics",
      logo: true,
      helpers: {
        formatBytes: function(bytes) {
          if (bytes === 0) return '0 Bytes';
          const k = 1024;
          const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
          const i = Math.floor(Math.log(bytes) / Math.log(k));
          return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        },
        progressBar: function(percent) {
          const color = percent > 90 ? 'danger' : percent > 70 ? 'warning' : 'success';
          return `
            <div class="progress" style="height: 20px;">
              <div class="progress-bar bg-${color}" role="progressbar" 
                   style="width: ${percent}%" 
                   aria-valuenow="${percent}" aria-valuemin="0" aria-valuemax="100">
                ${percent}%
              </div>
            </div>`;
        }
      }
    });

  } catch (error) {
    console.error("Node stats route failed:", error);
    res.status(500).render('admin/error', {
      error: "Internal Server Error",
      user: req.user
    });
  }
});

router.post("/admin/nodes/radar/check", isAdmin, async (req, res) => {
  try {
    const nodes = (await db.get("nodes")) || [];
    let instances = (await db.get("instances")) || [];

    for (const nodeid of nodes) {
      const node = await db.get(`${nodeid}_node`);
      if (node) {
        const nodestatus = await checkNodeStatus(node);
        if (nodestatus) {
          try {
            const response = await axios.get(
              `http://${node.address}:${node.port}/check/all`,
              {
                auth: {
                  username: "OGhost × NexusNode",
                  password: node.apiKey,
                },
              },
            );

            if (response.data.flaggedMessages.length > 0) {
              for (const message of response.data.flaggedMessages) {
                const { containerId, message: flaggedMessage } = message;
                for (let instance of instances) {
                  if (instance.ContainerId === containerId) {
                    instance.suspended = true;
                    instance["suspended-flagg"] = flaggedMessage;
                  }
                }
              }
            }
          } catch (error) {
            if (error.response && error.response.status === 401) {
            } else {
              console.error(`Error checking node ${nodeid}:`, error.message);
            }
          }
        }
      }
    }

    await db.set("instances", instances);

    res.status(200).send("Node checks completed.");
  } catch (error) {
    console.error("Error during node check:", error.message);
    res.status(500).send("An error occurred while checking nodes.");
  }
});

/**
 * POST /nodes/delete
 * Deletes a node from the database based on its identifier provided in the request body.
 */

router.post("/nodes/delete", async (req, res) => {
  const { nodeId } = req.body;
  if (!nodeId) {
    return res.status(400).json({ error: "Missing nodeId" });
  }

  try {
    const nodes = (await db.get("nodes")) || [];
    let foundNode = null;

    for (const id of nodes) {
      const node = await db.get(id + "_node");
      if (node && node.id === nodeId) {
        foundNode = node;
        break;
      }
    }

    if (!foundNode) {
      return res.status(404).json({ error: "Node not found" });
    }

    const node = foundNode;
    let instances = (await db.get("instances")) || [];
    let set = {};

    nodes.forEach(function (id) {
      set[id] = 0;
      instances.forEach(function (instance) {
        if (instance.Node.id === id) {
          set[id]++;
        }
      });
    });

    if (set[node.id] > 0) {
      if (!req.query.deleteinstances || req.query.deleteinstances === "false") {
        return res
          .status(400)
          .json({ error: "There are instances on the node" });
      }

      if (req.query.deleteinstances === "true") {
        let delinstances = instances.filter(function (instance) {
          return instance.Node.id === node.id;
        });

        instances = instances.filter(function (instance) {
          return instance.Node.id !== node.id;
        });

        await db.set("instances", instances);

        for (const instance of delinstances) {
          await db.delete(instance.Id + "_instance");
        }

        for (const instance of delinstances) {
          let userInstances =
            (await db.get(instance.User + "_instances")) || [];
          userInstances = userInstances.filter(
            (inst) => inst.Id !== instance.Id,
          );
          await db.set(instance.User + "_instances", userInstances);
        }

        try {
          await axios.get(
            `http://OGhost × NexusNode:${node.apiKey}@${node.address}:${node.port}/instances/purge/all`,
          );
        } catch (apiError) {
          console.error("Error calling purge API:", apiError);
        }
      }
    }

    await db.delete(node.id + "_node");
    nodes.splice(nodes.indexOf(node.id), 1);
    await db.set("nodes", nodes);

    logAudit(req.user.userId, req.user.username, "node:delete", req.ip);
    res.status(200).json({ success: true });
  } catch (error) {
    console.error("Error deleting node:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * POST /nodes/configure
 * Allows a node to set its own access key using the configureKey.
 * The request must include a valid authKey from config.json for security.
 */
router.post("/nodes/configure", async (req, res) => {
  const { configureKey, accessKey } = req.query;

  if (!configureKey || !accessKey) {
    return res.status(400).json({ error: "Missing configureKey or accessKey" });
  }

  try {
    // Find the node with the matching configureKey
    const nodes = (await db.get("nodes")) || [];
    let foundNode = null;
    for (const nodeId of nodes) {
      const node = await db.get(nodeId + "_node");
      if (node && node.configureKey === configureKey) {
        foundNode = node;
        break;
      }
    }

    if (!foundNode) {
      return res.status(404).json({ error: "Node not found" });
    }

    // Update the node with the new accessKey
    foundNode.apiKey = accessKey;
    foundNode.status = "Configured";
    foundNode.configureKey = null; // Remove the configureKey after successful configuration

    await db.set(foundNode.id + "_node", foundNode);

    res.status(200).json({ message: "Node configured successfully" });
  } catch (error) {
    console.error("Error configuring node:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/users/create", isAdmin, async (req, res) => {
  const { username, email, password, admin, verified } = req.body;

  if (!username || !email || !password) {
    return res.status(400).send("Username, email, and password are required.");
  }

  if (typeof admin !== "boolean") {
    return res.status(400).send("Admin field must be true or false.");
  }

  const userExists = await doesUserExist(username);
  if (userExists) {
    return res.status(400).send("User already exists.");
  }

  const emailExists = await doesEmailExist(email);
  if (emailExists) {
    return res.status(400).send("Email already exists.");
  }

  const userId = uuidv4();
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  const newUser = {
    userId,
    username,
    email,
    password: hashedPassword,
    accessTo: [],
    admin,
    verified: verified || false,
  };

  let users = (await db.get("users")) || [];
  users.push(newUser);
  await db.set("users", users);

  logAudit(req.user.userId, req.user.username, "user:create", req.ip);

  res.status(201).send(newUser);
});

router.delete("/user/delete", isAdmin, async (req, res) => {
  const userId = req.body.userId;
  const users = (await db.get("users")) || [];

  const userIndex = users.findIndex((user) => user.userId === userId);

  if (userIndex === -1) {
    return res.status(400).send("The specified user does not exist");
  }

  users.splice(userIndex, 1);
  await db.set("users", users);
  logAudit(req.user.userId, req.user.username, "user:delete", req.ip);
  res.status(204).send();
});

router.get("/admin/users/edit/:userId", isAdmin, async (req, res) => {
  const userId = req.params.userId;
  const users = (await db.get("users")) || [];
  const user = users.find((user) => user.userId === userId);

  if (!user) {
    return res.status(404).send("User not found");
  }

  res.render("admin/edit-user", {
    req,
    user: req.user,
    editUser: user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
  });
});

router.post("/admin/users/edit/:userId", isAdmin, async (req, res, next) => {
  const userId = req.params.userId;
  const { username, email, password, admin, verified } = req.body;

  if (!username || !email) {
    return res.status(400).send("Username and email are required.");
  }

  const users = (await db.get("users")) || [];
  const userIndex = users.findIndex((user) => user.userId === userId);

  if (userIndex === -1) {
    return res.status(404).send("User not found");
  }

  const userExists = users.some(
    (user) => user.username === username && user.userId !== userId,
  );
  const emailExists = users.some(
    (user) => user.email === email && user.userId !== userId,
  );

  if (userExists) {
    return res.status(400).send("Username already exists.");
  }

  if (emailExists) {
    return res.status(400).send("Email already exists.");
  }

  users[userIndex].username = username;
  users[userIndex].email = email;
  users[userIndex].admin = admin === "true";
  users[userIndex].verified = verified === "true";

  if (password) {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    users[userIndex].password = hashedPassword;
  }

  await db.set("users", users);

  logAudit(req.user.userId, req.user.username, "user:edit", req.ip);

  if (req.user.userId === userId) {
    return req.logout((err) => {
      if (err) return next(err);
      res.redirect("/login?err=UpdatedCredentials");
    });
  }

  res.redirect("/admin/users");
});

/**
 * DELETE /nodes/delete
 * Deletes a node from the database based on its identifier provided in the request body. Updates the list of
 * all nodes in the database to reflect this deletion. This operation is restricted to administrators.
 *
 * @returns {Response} Sends a status response indicating the successful deletion of the node.
 */
router.delete("/nodes/delete", isAdmin, async (req, res) => {
  const nodeId = req.body.nodeId;
  const nodes = (await db.get("nodes")) || [];
  const newNodes = nodes.filter((id) => id !== nodeId);

  if (!nodeId) return res.send("Invalid node");

  await db.set("nodes", newNodes);
  await db.delete(nodeId + "_node");
  logAudit(req.user.userId, req.user.username, "node:delete", req.ip);
  res.status(204).send();
});

/**
 * GET /admin/nodes
 * Retrieves a list of all nodes, checks their statuses, and renders an admin page to display these nodes.
 * This route is protected and allows only administrators to view the node management page.
 *
 * @returns {Response} Renders the 'nodes' view with node data and user information.
 */

router.get("/admin/nodes", isAdmin, async (req, res) => {
  let nodes = (await db.get("nodes")) || [];
  let instances = (await db.get("instances")) || [];
  let set = {};
  nodes.forEach(function (node) {
    set[node] = 0;
    instances.forEach(function (instance) {
      if (instance.Node.id == node) {
        set[node]++;
      }
    });
  });
  nodes = await Promise.all(
    nodes.map((id) => db.get(id + "_node").then(checkNodeStatus)),
  );

  res.render("admin/nodes", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    nodes,
    set,
  });
});

/**
 * GET /admin/settings
 * Settings page. This route is protected and allows only administrators to view the settings page.
 *
 * @returns {Response} Renders the 'nodes' view with node data and user information.
 */
router.get("/admin/settings", isAdmin, async (req, res) => {
  res.render("admin/settings/appearance", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    favicon: (await db.get("favicon")) || false,
    settings: await db.get("settings"),
  });
});

router.get("/admin/settings/smtp", isAdmin, async (req, res) => {
  try {
    const settings = await db.get("settings");
    const smtpSettings = (await db.get("smtp_settings")) || {};

    res.render("admin/settings/smtp", {
      req,
      user: req.user,
      name: (await db.get("name")) || "OGhost × NexusNode 2026",
      logo: (await db.get("logo")) || false,
      settings,
      smtpSettings,
    });
  } catch (error) {
    console.error("Error fetching settings:", error);
    res.status(500).send("Failed to fetch settings. Please try again later.");
  }
});

router.get("/admin/settings/theme", isAdmin, async (req, res) => {
  res.render("admin/settings/theme", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    settings: await db.get("settings"),
  });
});

router.post(
  "/admin/settings/toggle/force-verify",
  isAdmin,
  async (req, res) => {
    try {
      const settings = (await db.get("settings")) || {};
      settings.forceVerify = !settings.forceVerify;

      await db.set("settings", settings);
      logAudit(req.user.userId, req.user.username, "force-verify:edit", req.ip); // Adjust as per your logging needs

      res.redirect("/admin/settings");
    } catch (err) {
      console.error("Error toggling force verify:", err);
      res.status(500).send("Internal Server Error");
    }
  },
);

router.post("/admin/settings/change/name", isAdmin, async (req, res) => {
  const name = req.body.name;
  try {
    await db.set("name", [name]);
    logAudit(req.user.userId, req.user.username, "name:edit", req.ip);
    res.redirect("/admin/settings?changednameto=" + name);
  } catch (err) {
    console.error(err);
    res.status(500).send("Database error");
  }
});

router.post(
  "/admin/settings/change/theme/button-color",
  isAdmin,
  async (req, res) => {
    const buttoncolor = req.body.buttoncolor;
    let theme = require("../storage/theme.json");
    try {
      theme["button-color"] = buttoncolor;
      await fs.writeFileSync(
        "./storage/theme.json",
        JSON.stringify(theme, null, 2),
      );
      logAudit(req.user.userId, req.user.username, "name:edit", req.ip);
      res.redirect("/admin/settings/theme?changedbuttoncolorto=" + buttoncolor);
    } catch (err) {
      console.error(err);
      res.status(500).send("File writing error");
    }
  },
);

router.post(
  "/admin/settings/change/theme/paneltheme-color",
  isAdmin,
  async (req, res) => {
    const paneltheme = req.body.paneltheme;
    let theme = require("../storage/theme.json");
    try {
      theme["paneltheme-color"] = paneltheme;
      await fs.writeFileSync(
        "./storage/theme.json",
        JSON.stringify(theme, null, 2),
      );
      logAudit(req.user.userId, req.user.username, "name:edit", req.ip);
      res.redirect("/admin/settings/theme?changedpanelcolorto=" + paneltheme);
    } catch (err) {
      console.error(err);
      res.status(500).send("File writing error");
    }
  },
);

router.post(
  "/admin/settings/toggle/theme/footer",
  isAdmin,
  async (req, res) => {
    try {
      const settings = (await db.get("settings")) || {};
      settings.footer = !settings.footer;

      await db.set("settings", settings);
      const action = settings.footer ? "enabled" : "disabled";
      logAudit(req.user.userId, req.user.username, "footer:" + action, req.ip);

      res.redirect("/admin/settings/theme");
    } catch (err) {
      console.error("Error toggling force verify:", err);
      res.status(500).send("Internal Server Error");
    }
  },
);

router.post("/admin/settings/saveSmtpSettings", async (req, res) => {
  const {
    smtpServer,
    smtpPort,
    smtpUser,
    smtpPass,
    smtpFromName,
    smtpFromAddress,
  } = req.body;

  try {
    await db.set("smtp_settings", {
      server: smtpServer,
      port: smtpPort,
      username: smtpUser,
      password: smtpPass,
      fromName: smtpFromName,
      fromAddress: smtpFromAddress,
    });

    logAudit(req.user.userId, req.user.username, "SMTP:edit", req.ip);
    res.redirect("/admin/settings/smtp?msg=SmtpSaveSuccess");
  } catch (error) {
    console.error("Error saving SMTP settings:", error);
    res.redirect("/admin/settings/smtp?err=SmtpSaveFailed");
  }
});

router.post("/sendTestEmail", async (req, res) => {
  try {
    const { recipientEmail } = req.body;

    const emailSent = await sendTestEmail(recipientEmail);

    if (emailSent) {
      res.redirect("/admin/settings/smtp?msg=TestemailSentsuccess");
    } else {
      res.redirect("/admin/settings/smtp?err=TestemailSentfailed");
    }
  } catch (error) {
    console.error("Error sending test email:", error);
    res.redirect("/admin/settings/smtp?err=TestemailSentfailed");
  }
});

// Configure multer for file upload
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadPath = path.join(__dirname, "..", "public", "assets");
      fs.mkdirSync(uploadPath, { recursive: true });
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      cb(null, "logo.png");
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Not an image! Please upload an image file."), false);
    }
  },
});

router.post(
  "/admin/settings/change/logo",
  isAdmin,
  upload.single("logo"),
  async (req, res) => {
    const type = req.body.type;

    try {
      if (type === "image" && req.file) {
        // Image uploaded successfully
        await db.set("logo", true);
        res.redirect("/admin/settings");
      } else if (type === "none") {
        // Remove existing logo
        const logoPath = path.join(
          __dirname,
          "..",
          "public",
          "assets",
          "logo.png",
        );
        if (fs.existsSync(logoPath)) {
          fs.unlinkSync(logoPath);
        }
        await db.set("logo", false);
        logAudit(req.user.userId, req.user.username, "logo:edit", req.ip);
        res.redirect("/admin/settings");
      } else {
        res.status(400).send("Invalid request");
      }
    } catch (err) {
      console.error(err);
      res.status(500).send("Error processing logo change: " + err.message);
    }
  },
);

// Favicon upload
const faviconUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadPath = path.join(__dirname, "..", "public", "assets");
      fs.mkdirSync(uploadPath, { recursive: true });
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      cb(null, "favicon.png");
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Not an image!"), false);
    }
  },
});

router.post(
  "/admin/settings/change/favicon",
  isAdmin,
  faviconUpload.single("favicon"),
  async (req, res) => {
    const type = req.body.type;
    try {
      if (type === "image" && req.file) {
        await db.set("favicon", true);
        logAudit(req.user.userId, req.user.username, "favicon:edit", req.ip);
        res.redirect("/admin/settings");
      } else if (type === "none") {
        const faviconPath = path.join(__dirname, "..", "public", "assets", "favicon.png");
        if (fs.existsSync(faviconPath)) fs.unlinkSync(faviconPath);
        await db.set("favicon", false);
        logAudit(req.user.userId, req.user.username, "favicon:remove", req.ip);
        res.redirect("/admin/settings");
      } else {
        res.status(400).send("Invalid request");
      }
    } catch (err) {
      console.error(err);
      res.status(500).send("Error processing favicon: " + err.message);
    }
  },
);

router.post(
  "/admin/settings/toggle/register",
  isAdmin,
  upload.single("logo"),
  async (req, res) => {
    let settings = await db.get("settings");
    settings.register = !settings.register;
    await db.set("settings", settings);
    logAudit(req.user.userId, req.user.username, "register:edit", req.ip);
    res.redirect("/admin/settings");
  },
);
/**
 * GET /admin/instances
 * Retrieves a list of all instances, checks their statuses, and renders an admin page to display these instances.
 * This route is protected and allows only administrators to view the instance management page.
 *
 * @returns {Response} Renders the 'instances' view with instance data and user information.
 */
async function processInstances() {
  try {
    // Get all instances from the "instances" database
    const instances = await db.get("instances");

    if (!instances || instances.length === 0) {
      console.log("No instances found.");
      return;
    }

    // Iterate over each instance in the database
    for (const instance of instances) {
      try {
        // Fetch the current state from the remote server
        const getStateUrl = `http://${instance.Node.address}:${instance.Node.port}/instances/${instance.Id}/states/get`;
        const getStateResponse = await axios.get(getStateUrl, {
          auth: {
            username: "OGhost × NexusNode",
            password: instance.Node.apiKey,
          },
        });

        const newState = getStateResponse.data.state;

        // Update the state on the remote server
        const setStateUrl = `http://${instance.Node.address}:${instance.Node.port}/instances/${instance.Id}/states/set/${newState}`;
        await axios.get(setStateUrl, {
          auth: {
            username: "OGhost × NexusNode",
            password: instance.Node.apiKey,
          },
        });

        // Ensure the instance in the "instances" database has the "State" property
        if (!instance.hasOwnProperty("State")) {
        }
        instance.State = newState;

        // Get the instance-specific database and ensure it has the "State" property
        const instanceDbKey = `${instance.Id}_instance`;
        let instanceDb = await db.get(instanceDbKey);

        if (!instanceDb) {
          instanceDb = {};
        }

        if (!instanceDb.hasOwnProperty("State")) {
        }
        instanceDb.State = newState;

        // Save the updated instance-specific database
        await db.set(instanceDbKey, instanceDb);
      } catch (instanceError) {
        console.error(
          `Error processing instance ${instance.Id}:`,
          instanceError.message,
        );
      }
    }

    // Save the updated "instances" array back to the database
    await db.set("instances", instances);
  } catch (error) {
    console.error("Error processing instances:", error.message);
  }
}
router.get("/admin/instances", isAdmin, async (req, res) => {
  try {
    let instances = (await db.get("instances")) || [];
    let images = (await db.get("images")) || [];
    let nodes = (await db.get("nodes")) || [];
    let users = (await db.get("users")) || [];

    nodes = await Promise.all(
      nodes.map((id) => db.get(id + "_node").then(checkNodeStatus)),
    );
    await processInstances();

    res.render("admin/instances", {
      req,
      user: req.user,
      name: (await db.get("name")) || "OGhost × NexusNode 2026",
      logo: (await db.get("logo")) || false,
      instances,
      images,
      nodes,
      users,
    });
  } catch (error) {
    console.error("Error loading admin/instances:", error);
    res.status(500).send("An error occurred while processing the request.");
  }
});

router.get("/admin/instances/:id/edit", isAdmin, async (req, res) => {
  const { id } = req.params;
  const instance = await db.get(id + "_instance");
  let users = (await db.get("users")) || [];
  let images = (await db.get("images")) || [];

  if (!instance) return res.redirect("/admin/instances");
  res.render("admin/instance_edit", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    instance,
    images,
    users,
  });
});

router.get("/admin/users", isAdmin, async (req, res) => {
  res.render("admin/users", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    users: (await db.get("users")) || [],
  });
});

/**
 * GET /admin/node/:id
 * Renders the page for a specific node identified by its unique ID.
 * The endpoint retrieves the node details from the database,
 * and renders the 'admin/node' view with the retrieved data.
 *
 * @param {string} id - The unique identifier of the node to fetch.
 * @returns {Response} Redirects to the nodes overview page if the node does not exist
 * or the ID is not provided. Otherwise, renders the node page with appropriate data.
 */

router.get("/admin/node/:id", async (req, res) => {
  const { id } = req.params;
  const node = await db.get(id + "_node");

  if (!node || !id) return res.redirect("../nodes");

  res.render("admin/node", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    node,
  });
});

/**
 * POST /admin/node/:id
 * Edit an existing node with specified parameters from the request body, such as name, hardware specifications.
 *
 * @returns {Response} Sends the node data if all goes ok else 400 if the node doesn't exist.
 */

router.post("/admin/node/:id", async (req, res) => {
  const { id } = req.params;
  const cnode = await db.get(id + "_node");

  if (!cnode || !id) return res.status(400).send();

  const node = {
    id: id,
    name: req.body.name,
    tags: req.body.tags,
    ram: req.body.ram,
    disk: req.body.disk,
    processor: req.body.processor,
    address: req.body.address,
    port: req.body.port,
    apiKey: req.body.apiKey,
    status: "Unknown", // Default status
  };

  await db.set(node.id + "_node", node);
  const updatedNode = await checkNodeStatus(node);
  res.status(201).send(updatedNode);
});

/**
 * GET /admin/images
 *
 * @returns {Response} Renders the 'images' view with image data.
 */
router.get("/admin/images", isAdmin, async (req, res) => {
  res.render("admin/images", {
    req,
    user: req.user,
    name: (await db.get("name")) || "OGhost × NexusNode 2026",
    logo: (await db.get("logo")) || false,
    images: (await db.get("images")) || [],
  });
});

router.post("/admin/images/upload", isAdmin, async (req, res) => {
  try {
    let jsonData = req.body;
    jsonData.Id = uuidv4();
    let images = (await db.get("images")) || [];
    images.push(jsonData);
    await db.set("images", images);
    res.status(200).send("image uploaded successfully.");
  } catch (err) {
    console.error("Error uploading image:", err);
    res.status(500).send("Error uploading image.");
  }
});

router.post("/admin/images/delete", isAdmin, async (req, res) => {
  try {
    let { id } = req.body;
    let images = (await db.get("images")) || [];
    images = images.filter((image) => image.Id !== id);
    await db.set("images", images);
    res.status(200).send("image deleted successfully.");
  } catch (err) {
    console.error("Error deleting image:", err);
    res.status(500).send("Error deleting image.");
  }
});

// Endpoint to delete a single instance
router.get("/admin/instance/delete/:id", isAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    if (!id) {
      return res.redirect("/admin/instances");
    }

    const instance = await db.get(id + "_instance");
    if (!instance) {
      return res.status(404).send("Instance not found");
    }

    await deleteInstance(instance);
    logAudit(req.user.userId, req.user.username, "instance:delete", req.ip);
    res.redirect("/admin/instances");
  } catch (error) {
    console.error("Error in delete instance endpoint:", error);
    res.status(500).send("An error occurred while deleting the instance");
  }
});

// Endpoint to purge all instances
router.get("/admin/instances/purge/all", isAdmin, async (req, res) => {
  try {
    const instances = (await db.get("instances")) || [];

    for (const instance of instances) {
      await deleteInstance(instance);
    }

    await db.delete("instances");
    res.redirect("/admin/instances");
  } catch (error) {
    console.error("Error in purge all instances endpoint:", error);
    res.status(500).send("An error occurred while purging all instances");
  }
});

router.post("/admin/instances/suspend/:id", isAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    if (!id) {
      return res.redirect("/admin/instances");
    }
    const instance = await db.get(id + "_instance");
    if (!instance) {
      return res.status(404).send("Instance not found");
    }

    instance.suspended = true;
    await db.set(id + "_instance", instance);
    let instances = (await db.get("instances")) || [];

    let instanceToSuspend = instances.find(
      (obj) => obj.ContainerId === instance.ContainerId,
    );
    if (instanceToSuspend) {
      instanceToSuspend.suspended = true;
    }

    await db.set("instances", instances);

    logAudit(req.user.userId, req.user.username, "instance:suspend", req.ip);
    res.redirect("/admin/instances");
  } catch (error) {
    console.error("Error in suspend instance endpoint:", error);
    res.status(500).send("An error occurred while suspending the instance");
  }
});

router.post("/admin/instances/unsuspend/:id", isAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    if (!id) {
      return res.redirect("/admin/instances");
    }
    const instance = await db.get(id + "_instance");
    if (!instance) {
      return res.status(404).send("Instance not found");
    }

    instance.suspended = false;

    await db.set(id + "_instance", instance);

    let instances = (await db.get("instances")) || [];

    let instanceToUnsuspend = instances.find(
      (obj) => obj.ContainerId === instance.ContainerId,
    );
    if (instanceToUnsuspend) {
      instanceToUnsuspend.suspended = false;
    }

    await db.set("instances", instances);

    logAudit(req.user.userId, req.user.username, "instance:unsuspend", req.ip);

    res.redirect("/admin/instances");
  } catch (error) {
    console.error("Error in unsuspend instance endpoint:", error);
    res.status(500).send("An error occurred while unsuspending the instance");
  }
});

const workflowsFilePath = path.join(__dirname, "../storage/workflows.json");

async function deleteInstance(instance) {
  try {
    await axios.get(
      `http://OGhost × NexusNode:${instance.Node.apiKey}@${instance.Node.address}:${instance.Node.port}/instances/${instance.ContainerId}/delete`,
    );

    let userInstances = (await db.get(instance.User + "_instances")) || [];
    userInstances = userInstances.filter(
      (obj) => obj.ContainerId !== instance.ContainerId,
    );
    await db.set(instance.User + "_instances", userInstances);

    let globalInstances = (await db.get("instances")) || [];
    globalInstances = globalInstances.filter(
      (obj) => obj.ContainerId !== instance.ContainerId,
    );
    await db.set("instances", globalInstances);

    await db.delete(instance.ContainerId + "_instance");
    await deleteWorkflowFromFile(instance.Id);
  } catch (error) {
    console.error(`Error deleting instance ${instance.ContainerId}:`, error);
    throw error;
  }
}

function deleteWorkflowFromFile(instanceId) {
  try {
    if (fs.existsSync(workflowsFilePath)) {
      const data = fs.readFileSync(workflowsFilePath, "utf8");
      const workflows = JSON.parse(data);

      if (workflows[instanceId]) {
        delete workflows[instanceId];
        fs.writeFileSync(
          workflowsFilePath,
          JSON.stringify(workflows, null, 2),
          "utf8",
        );
        console.log(
          `Workflow for instance ${instanceId} deleted successfully from file.`,
        );
      } else {
        console.log(
          `No workflow found for instance ${instanceId} in the file.`,
        );
      }
    } else {
      console.error("Workflows file does not exist.");
    }
  } catch (error) {
    console.error("Error deleting workflow from file:", error);
  }
}

router.get("/admin/auditlogs", isAdmin, async (req, res) => {
  try {
    let audits = await db.get("audits");
    audits = audits ? JSON.parse(audits) : [];
    res.render("admin/auditlogs", {
      req,
      user: req.user,
      name: (await db.get("name")) || "OGhost × NexusNode 2026",
      logo: (await db.get("logo")) || false,
      audits,
    });
  } catch (err) {
    console.error("Error fetching audits:", err);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
