const express = require('express');
const router = express.Router();
const WebSocket = require('ws');
const { db } = require('../../../handlers/db.js');
const { isUserAuthorizedForContainer } = require('../../../utils/authHelper');

router.ws("/console/:id", async (ws, req) => {
    if (!req.user) return ws.close(1008, "Authorization required");

    const { id } = req.params;
    const instance = await db.get(id + '_instance');

    if (!instance || !id) return ws.close(1008, "Invalid instance or ID");

    const isAuthorized = await isUserAuthorizedForContainer(req.user.userId, instance.Id);
    if (!isAuthorized) {
        return ws.close(1008, "Unauthorized access");
    }

    const node = instance.Node;
    const socket = new WebSocket(`ws://${node.address}:${node.port}/exec/${instance.ContainerId}`);

    // Heartbeat: keep connection alive with ping every 20s
    let pingInterval = null;

    socket.onopen = () => {
        socket.send(JSON.stringify({ "event": "auth", "args": [node.apiKey] }));
        // Start heartbeat ping to node daemon
        pingInterval = setInterval(() => {
            if (socket.readyState === WebSocket.OPEN) {
                socket.ping();
            }
        }, 20000);
    };

    socket.on('pong', () => {
        // Node daemon is alive, connection healthy
    });

    socket.onmessage = msg => {
        if (ws.readyState === ws.OPEN) {
            ws.send(msg.data);
        }
    };

    socket.onerror = (error) => {
        if (ws.readyState === ws.OPEN) {
            ws.send('\x1b[31;1mThis instance is unavailable! \n\x1b[0mThe daemon instance appears to be down. Retrying...\n');
        }
    };

    socket.onclose = (event) => {
        if (pingInterval) clearInterval(pingInterval);
    };

    ws.onmessage = msg => {
        if (socket.readyState === WebSocket.OPEN) {
            socket.send(msg.data);
        }
    };

    // Client-side ping — browser sends ping frames to panel
    ws.on('ping', () => {
        ws.pong();
    });

    ws.on('close', () => {
        if (pingInterval) clearInterval(pingInterval);
        socket.close();
    });
});

/* you'll remember in November, someone knows the meaning of this */
/* SSB0aGluayB0aGlzIHRpbWUgSSdtIGR5aW5nCkknbSBub3QgbWVsb2RyYW1hdGljCkknbSBqdXN0IHByYWdtYXRpYyBiZXlvbmQgYW55ClJlYXNvbmluZyBmb3IgdGhpbmtpbmcgSSd2ZSBnb3QgZnVja2luZyByYWJpZXMgb3Igc29tZXRoaW5n */
module.exports = router;