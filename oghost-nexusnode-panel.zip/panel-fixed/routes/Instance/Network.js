const express = require('express');
const router = express.Router();
const { db } = require('../../handlers/db.js');
const { isUserAuthorizedForContainer } = require('../../utils/authHelper');

const { loadPlugins } = require('../../plugins/loadPls.js');
const path = require('path');

const plugins = loadPlugins(path.join(__dirname, '../../plugins'));

router.get("/instance/:id/network", async (req, res) => {
    if (!req.user) return res.redirect('/');

    const { id } = req.params;
    if (!id) return res.redirect('../instances');

    const instance = await db.get(id + '_instance').catch(err => {
        console.error('Failed to fetch instance:', err);
        return null;
    });

    if (!instance) return res.status(404).send('Instance not found');

    const isAuthorized = await isUserAuthorizedForContainer(req.user.userId, instance.Id);
    if (!isAuthorized) {
        return res.status(403).send('Unauthorized access to this instance.');
    }

    if (!instance.suspended) {
        instance.suspended = false;
        db.set(id + '_instance', instance);
    }
    if (instance.suspended === true) {
        return res.redirect('../../instances?err=SUSPENDED');
    }

    const allPluginData = Object.values(plugins).map(plugin => plugin.config);
    const ports = processPorts(instance.Ports, instance);

    res.render('instance/network', {
        req,
        user: req.user,
        name: await db.get('name') || 'OGhost × NexusNode 2026',
        logo: await db.get('logo') || false,
        instance,
        ports,
        addons: {
            plugins: allPluginData
        }
    });
});

// POST: Add a new port allocation
router.post("/instance/:id/network/add", async (req, res) => {
    if (!req.user) return res.redirect('/');

    const { id } = req.params;
    const { externalPort, internalPort } = req.body;

    if (!externalPort || !internalPort) {
        return res.redirect(`/instance/${id}/network?err=MISSING_PORTS`);
    }

    const extPort = parseInt(externalPort);
    const intPort = parseInt(internalPort);

    if (isNaN(extPort) || isNaN(intPort) || extPort < 1 || extPort > 65535 || intPort < 1 || intPort > 65535) {
        return res.redirect(`/instance/${id}/network?err=INVALID_PORT`);
    }

    const instance = await db.get(id + '_instance').catch(() => null);
    if (!instance) return res.status(404).send('Instance not found');

    const isAuthorized = await isUserAuthorizedForContainer(req.user.userId, instance.Id);
    if (!isAuthorized) return res.status(403).send('Unauthorized');

    const existingPorts = processPorts(instance.Ports, instance);
    const portExists = existingPorts.some(p => p.port === extPort);
    if (portExists) {
        return res.redirect(`/instance/${id}/network?err=PORT_EXISTS`);
    }

    const newPortMapping = `${extPort}:${intPort}`;
    instance.Ports = instance.Ports 
        ? instance.Ports + ',' + newPortMapping 
        : newPortMapping;

    await db.set(id + '_instance', instance);
    return res.redirect(`/instance/${id}/network?success=PORT_ADDED`);
});

// POST: Delete a port allocation
router.post("/instance/:id/network/delete", async (req, res) => {
    if (!req.user) return res.redirect('/');

    const { id } = req.params;
    const { port } = req.body;

    if (!port) return res.redirect(`/instance/${id}/network?err=MISSING_PORT`);

    const instance = await db.get(id + '_instance').catch(() => null);
    if (!instance) return res.status(404).send('Instance not found');

    const isAuthorized = await isUserAuthorizedForContainer(req.user.userId, instance.Id);
    if (!isAuthorized) return res.status(403).send('Unauthorized');

    // Cannot delete primary port
    if (instance.Primary === port) {
        return res.redirect(`/instance/${id}/network?err=CANNOT_DELETE_PRIMARY`);
    }

    const portMappings = instance.Ports ? instance.Ports.split(',') : [];
    const filteredPorts = portMappings.filter(mapping => {
        const [external] = mapping.split(':');
        return external.trim() !== String(port);
    });

    instance.Ports = filteredPorts.join(',');
    await db.set(id + '_instance', instance);
    return res.redirect(`/instance/${id}/network?success=PORT_DELETED`);
});

// POST: Set primary port
router.post("/instance/:id/network/primary", async (req, res) => {
    if (!req.user) return res.redirect('/');

    const { id } = req.params;
    const { port } = req.body;

    if (!port) return res.redirect(`/instance/${id}/network?err=MISSING_PORT`);

    const instance = await db.get(id + '_instance').catch(() => null);
    if (!instance) return res.status(404).send('Instance not found');

    const isAuthorized = await isUserAuthorizedForContainer(req.user.userId, instance.Id);
    if (!isAuthorized) return res.status(403).send('Unauthorized');

    const ports = processPorts(instance.Ports, instance);
    const portExists = ports.some(p => String(p.port) === String(port));
    if (!portExists) return res.redirect(`/instance/${id}/network?err=PORT_NOT_FOUND`);

    instance.Primary = String(port);
    await db.set(id + '_instance', instance);
    return res.redirect(`/instance/${id}/network?success=PRIMARY_SET`);
});

function processPorts(portsString, instance) {
    if (!portsString) return [];
    
    return portsString.split(',').filter(Boolean).map(mapping => {
        const [external, internal] = mapping.trim().split(':');
        return {
            port: parseInt(external),
            primary: String(instance.Primary) === String(external).trim(),
            internal: parseInt(internal)
        };
    });
}

module.exports = router;
