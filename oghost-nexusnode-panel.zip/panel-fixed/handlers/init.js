const { db } = require('../handlers/db.js');
const config = require('../config.json');
const { v4: uuidv4 } = require('uuid');
const CatLoggr = require('cat-loggr');
const log = new CatLoggr();

async function init() {
    const panelInstance = await db.get('oghost_instance');
    if (!panelInstance) {
        log.init('Welcome to OGhost × NexusNode 2026! First time setup detected.');
        log.init('Documentation: github.com/nexusnode');

        let imageCheck = await db.get('images');
        if (!imageCheck) {
            log.error('Before starting for the first time, you need to run the seed command!');
            log.error('Please run: npm run seed');
            log.error('Then create a user: npm run createUser');
            process.exit();
        }

        let panelId = uuidv4();
        let setupTime = Date.now();
        
        let info = {
            panelId: panelId,
            setupTime: setupTime,
            originalVersion: config.version
        };

        await db.set('oghost_instance', info);
        log.info('OGhost × NexusNode 2026 initialized with id: ' + panelId);
    }        

    log.info('Init complete!');
}

module.exports = { init };
