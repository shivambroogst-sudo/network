---
# oghost-nexusnode-panel

## Overview


---

## Prerequisites

Before getting started, ensure you have the following installed:

- **Git**: For cloning the repository.

---

## Installation

Follow the steps below to set up and run the panel:

setup vps

   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   ```

   ```bash
   sudo apt-get install -y nodejs
   ```

   ```bash
   curl -sSL https://get.docker.com/ | CHANNEL=stable bash
   ```

1. Clone the repository:
   ```bash
   git clone https://github.com/oghost-nexusnode-dev/panel
   ```

2. Navigate into the project directory:
   ```bash
   cd panel
   ```

3. Install dependencies using Bun:
   ```bash
   npm install
   ```

4. Configure the seed:
   ```bash
   npm run seed
   ```
5. Creation admin:
   ```bash
   npm run createUser
   ```


---

## Running the panel

To start the panel, use the following command:

```bash
node .
```

---
